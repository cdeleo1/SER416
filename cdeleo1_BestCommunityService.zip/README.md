# SER416 Final Project
## Best Community Service Web Application

### Author: Cristi DeLeo
### Last Revision: 03 March 2020

### Technologies Used:
	- nodejs
	- express
	- mongodb
	- okta
